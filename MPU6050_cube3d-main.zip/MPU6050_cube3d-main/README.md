# MPU6050_cube3d
3d cube MPU6050 Ardino html python
![sad](https://github.com/user-attachments/assets/262c285e-3731-498b-b828-5d87e5594f14)
